# 🛡️ CogniGuard AI Safety Platform

**AI Safety & Misinformation Detection Platform**

The first multi-agent AI communication security platform.


Based on the ACL 2025 paper: *"When Claims Evolve: Evaluating and Enhancing the Robustness of Embedding Models Against Misinformation Edits"*

## Installation

```bash
pip install cogniguard

## 🎯 Features

- **Multi-Stage Threat Detection** - 4-stage pipeline catches complex threats
- **Real-World Prevention** - Stops Sydney, Samsung, and Auto-GPT style attacks
- **Research-Based** - Built on ACL 2025 and EMNLP 2023 papers
- **Beautiful Dashboard** - Cyberpunk-themed Streamlit interface

## 🚀 Live Demo

[**Try it live!**](https://your-cogniguard.streamlit.app)

## 📊 Screenshots

![Dashboard](https://via.placeholder.com/800x400.png?text=CogniGuard+Dashboard)

## 🔧 Local Development

```bash
# Clone the repo
git clone https://github.com/your-username/cogniguard.git
cd cogniguard

# Install dependencies
pip install -r requirements.txt

# Run locally
streamlit run app.py


📚 Documentation
Visit the "About & Documentation" page in the app for full details.

🛡️ Threat Detection
CogniGuard detects:

✅ Goal hijacking (Sydney-style)
✅ Data exfiltration (Samsung-style)
✅ Power-seeking (Auto-GPT-style)
✅ Emergent collusion
✅ Social engineering
📄 License
Educational and research use.

👤 Author
Built by louisa wamuyu saburi



Protecting the Future of Multi-Agent AI Communication 🚀

Markdown

# 🛡️ CogniGuard AI Safety Platform

The first multi-agent AI communication security platform.

## 🎯 Features

- **Multi-Stage Threat Detection** - 4-stage pipeline catches complex threats
- **Real-World Prevention** - Stops Sydney, Samsung, and Auto-GPT style attacks
- **Research-Based** - Built on ACL 2025 and EMNLP 2023 papers
- **Beautiful Dashboard** - Cyberpunk-themed Streamlit interface

## 🚀 Live Demo

[**Try it live!**](https://your-cogniguard.streamlit.app)

## 📊 Screenshots

![Dashboard](https://via.placeholder.com/800x400.png?text=CogniGuard+Dashboard)

## 🔧 Local Development

```bash
# Clone the repo
git clone https://github.com/your-username/cogniguard.git
cd cogniguard

# Install dependencies
pip install -r requirements.txt

# Run locally
streamlit run app.py
📚 Documentation
Visit the "About & Documentation" page in the app for full details.

🛡️ Threat Detection
CogniGuard detects:

✅ Goal hijacking (Sydney-style)
✅ Data exfiltration (Samsung-style)
✅ Power-seeking (Auto-GPT-style)
✅ Emergent collusion
✅ Social engineering
📄 License
Educational and research use.

from cogniguard import ClaimAnalyzer

analyzer = ClaimAnalyzer()
result = analyzer.analyze("Th3 vaxx is s4fe fr fr no cap")

if result.is_perturbed:
    print("⚠️ Perturbations detected!")
    for p in result.perturbations_detected:
        print(f"  - {p.perturbation_type.value}: {p.explanation}")

        cogniguard analyze "Th3 vaxx is s4fe fr fr no cap"

        
Save and close.

---

### Step 1.3: Create a LICENSE File

```bash
notepad LICENSE

MIT License

Copyright (c) 2024 Your Name

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

👤 Author
Built by [Your Name]

Protecting the Future of Multi-Agent AI Communication 🚀






